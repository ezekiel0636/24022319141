/*
 * Author: 24022319141 (Ezekiel Raphael Mwailuka)
 *
 * Functionality:
 * Read one or more eye-tracker scanpaths and output, for each scanpath, the
 * distinct fixation coordinates in first-encounter order, renumbered with
 * contiguous identifiers beginning at one. A fixation point is considered a
 * duplicate of an earlier one if it shares the same (x, y) coordinates,
 * regardless of its original identifier.
 *
 * Format of input and output:
 * Input is read from ../data/input.txt.
 *   Line 1:            an integer N, the number of scanpaths (1 <= N <= 10).
 *   For each scanpath:  a sequence of records "id x y", one per line, ending
 *                        with the sentinel record "-1 -1" (x == -1, y == -1).
 *                        A scanpath has at most 1000 fixation points, with
 *                        0 <= x, y <= 2000.
 * Output is written to ../data/output.txt.
 *   Line 1:             the registration number.
 *   For each scanpath:   one line "id x y" per distinct fixation point, in
 *                        the order first encountered, with id renumbered
 *                        contiguously starting at 1 (the sentinel is never
 *                        written), followed by a line of fifteen asterisks
 *                        ("***************") that terminates that
 *                        scanpath's list.
 *
 * Solution strategy (pseudo-code):
 *   read N
 *   write registration number
 *   for each of the N scanpaths:
 *       clear the hash table
 *       new_id <- 1
 *       loop:
 *           read id, x, y
 *           if (x == -1 and y == -1): break
 *           key <- pack(x, y)                 // x * 2001 + y, injective on
 *                                              // the valid coordinate range
 *           if insert_if_absent(key):          // key not seen before
 *               write "new_id x y"
 *               new_id <- new_id + 1
 *       write "**********"
 *
 * The "seen before" test is implemented as a manually written separate
 * chaining hash table (no STL containers/algorithms): an array of
 * kBucketCount singly linked lists of HashNode. insert_if_absent hashes the
 * key with a small integer mixing function (finalizer-style avalanche) to
 * choose a bucket, walks that bucket's list looking for an existing node
 * with the same key, and either reports "already present" or allocates and
 * prepends a new node and reports "newly inserted". clear_table walks every
 * bucket, frees its nodes, and resets the bucket pointer to nullptr; it is
 * called once before every scanpath so that duplicates are only detected
 * within a single scanpath, never across scanpaths.
 *
 * Testing summary and test strategy:
 * The accompanying data/input.txt exercises:
 *   - all-unique points (no duplicates removed),
 *   - immediately repeated points (e.g. 695,241 twice in a row),
 *   - non-consecutive repeats separated by other points,
 *   - several distinct points that collapse to the same identifier through
 *     repeated (x, y) values (e.g. six records all equal to (13, 13)),
 *   - boundary coordinates 0 and 2000 on both axes, including the corners
 *     (0,0) and (2000,2000),
 *   - the maximum scanpath length of 1000 fixation points to check
 *     performance and that clear_table correctly frees a fully populated
 *     table,
 *   - multiple scanpaths (7) in a single run to confirm the table is reset
 *     between scanpaths and identifiers restart at 1 each time.
 * Output was inspected manually and cross-checked against the two worked
 * examples in the assignment brief, which this program reproduces exactly.
 *
 * Complexity analysis:
 * Let n be the number of fixation-point records in a scanpath (n <= 1000)
 * and u <= n be the number of distinct coordinates among them.
 *   - coordinate_key/bucket_index: O(1) each.
 *   - insert_if_absent: O(1) expected, since kBucketCount (2003) is chosen
 *     large relative to n and the hash mixing function distributes keys
 *     roughly uniformly, keeping expected bucket-chain length constant.
 *   - process_scanpath: O(n) expected time overall (n insert/lookup calls),
 *     O(u) auxiliary space for the u nodes actually stored.
 *   - clear_table: O(u) time, freeing exactly the nodes inserted since the
 *     last clear.
 * Across all N scanpaths the total expected time is O(sum of n_i) and the
 * auxiliary space at any moment is O(u_i) for the scanpath being processed,
 * since the table is cleared between scanpaths.
 */

#include "FixationPoints.h"

namespace {

constexpr const char* registrationNumber = "24022319141";
constexpr const char* inputFile = "../data/input.txt";
constexpr const char* outputFile = "../data/output.txt";
constexpr const char* separator = "***************";

}  // namespace

FixationPoints::FixationPoints() {
    for (unsigned int index = 0; index < kBucketCount; ++index) {
        buckets_[index] = nullptr;
    }
}

FixationPoints::~FixationPoints() {
    clear_table();
}

unsigned int FixationPoints::coordinate_key(int x, int y) {
    return static_cast<unsigned int>(x) * kCoordinateRange +
           static_cast<unsigned int>(y);
}

unsigned int FixationPoints::bucket_index(unsigned int key) {
    key ^= key >> 16U;
    key *= 0x7feb352dU;
    key ^= key >> 15U;
    return key % kBucketCount;
}

bool FixationPoints::insert_if_absent(unsigned int key) {
    const unsigned int index = bucket_index(key);
    HashNode* current = buckets_[index];

    // Walk the chain for this bucket to see if the key is already present.
    while (current != nullptr) {
        if (current->key == key) {
            return false;  // Duplicate coordinate: already inserted before.
        }
        current = current->next;
    }

    // Not found: allocate a new node and prepend it to the bucket's chain.
    HashNode* node = new HashNode;
    node->key = key;
    node->next = buckets_[index];
    buckets_[index] = node;

    return true;
}

void FixationPoints::clear_table() {
    for (unsigned int index = 0; index < kBucketCount; ++index) {
        HashNode* current = buckets_[index];
        while (current != nullptr) {
            HashNode* next = current->next;
            delete current;
            current = next;
        }
        buckets_[index] = nullptr;
    }
}

int FixationPoints::process_scanpath(FILE* input, FILE* output) {
    clear_table();
    int output_identifier = 1;

    int id = 0;
    int x = 0;
    int y = 0;

    while (fscanf(input, "%d %d %d", &id, &x, &y) == 3) {
        if (x == -1 && y == -1) {
            break;
        }

        const unsigned int key = coordinate_key(x, y);
        if (insert_if_absent(key)) {
            fprintf(output, "%d %d %d\n", output_identifier, x, y);
            ++output_identifier;
        }
    }

    fprintf(output, "%s\n", separator);

    return 0;
}

int FixationPoints::process() {
    FILE* input = fopen(inputFile, "r");
    if (input == nullptr) {
        return 1;
    }

    FILE* output = fopen(outputFile, "w");
    if (output == nullptr) {
        fclose(input);
        return 1;
    }

    fprintf(output, "%s\n", registrationNumber);

    int scanpath_count = 0;
    if (fscanf(input, "%d", &scanpath_count) != 1) {
        fclose(input);
        fclose(output);
        return 1;
    }

    for (int i = 0; i < scanpath_count; ++i) {
        process_scanpath(input, output);
    }

    fclose(input);
    fclose(output);

    return 0;
}
