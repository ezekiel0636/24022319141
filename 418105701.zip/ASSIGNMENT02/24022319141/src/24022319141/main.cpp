#include "FixationPoints.h"

int main() {
    FixationPoints fixationPoints;
    return fixationPoints.process();
}
