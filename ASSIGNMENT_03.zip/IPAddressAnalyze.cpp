#include "IPAddressAnalyze.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>

// ============================================================
// This file intentionally avoids the Standard Template Library
// entirely, per the assignment's explicit requirement. Every
// data structure and algorithm below (hash table, dynamic
// array, quicksort) is implemented from scratch using plain C
// arrays, malloc/realloc/free, and C-style character arrays.
//
// Memory-efficiency notes:
//  - Each hash slot is only 8 bytes (uint32_t ip + unsigned int
//    count), with zero padding, instead of carrying a bool
//    "used" flag inside the struct (which would cost an extra
//    4-8 bytes per slot due to alignment). "Used" tracking is
//    instead kept in a separate 1-bit-per-slot bitset.
//  - After counting, occupied slots are compacted to the front
//    of the SAME array in place (no second array is allocated),
//    then the array is shrunk with realloc() before sorting.
// ============================================================

// ------------------------------------------------------------
// Custom open-addressing hash table: IP (uint32) -> count
// ------------------------------------------------------------
struct HashEntry {
    uint32_t ip;
    unsigned int count;
};

struct HashTable {
    HashEntry* entries;
    uint8_t* usedBits; // 1 bit per slot, packed
    size_t capacity;   // always a power of two
    size_t size;       // number of occupied slots
};

static size_t nextPowerOfTwo(size_t n) {
    size_t p = 1;
    while (p < n) p <<= 1;
    return p;
}

static inline bool bitGet(const uint8_t* bits, size_t i) {
    return (bits[i >> 3] >> (i & 7)) & 1u;
}
static inline void bitSet(uint8_t* bits, size_t i) {
    bits[i >> 3] |= (uint8_t)(1u << (i & 7));
}

static void htInit(HashTable* ht, size_t initialCapacity) {
    ht->capacity = nextPowerOfTwo(initialCapacity);
    ht->entries = (HashEntry*)malloc(sizeof(HashEntry) * ht->capacity);
    ht->usedBits = (uint8_t*)calloc((ht->capacity + 7) / 8, 1);
    ht->size = 0;
}

static void htDestroy(HashTable* ht) {
    free(ht->entries);
    free(ht->usedBits);
    ht->entries = nullptr;
    ht->usedBits = nullptr;
    ht->capacity = 0;
    ht->size = 0;
}

// Fibonacci-style multiplicative mixing so sequential/nearby IPs
// spread evenly across buckets instead of clustering.
static inline size_t hashIp(uint32_t ip, size_t capacityMask) {
    uint64_t h = ip;
    h ^= (h >> 16);
    h *= 0x9E3779B97F4A7C15ULL;
    h ^= (h >> 32);
    return (size_t)(h & capacityMask);
}

// Insert into a raw entries array (used both for normal inserts
// and for rehashing during a grow).
static void htInsertRaw(HashEntry* entries, uint8_t* usedBits, size_t capacity,
                         uint32_t ip, unsigned int count) {
    size_t mask = capacity - 1;
    size_t idx = hashIp(ip, mask);
    while (bitGet(usedBits, idx)) {
        if (entries[idx].ip == ip) {
            entries[idx].count += count;
            return;
        }
        idx = (idx + 1) & mask; // linear probing
    }
    entries[idx].ip = ip;
    entries[idx].count = count;
    bitSet(usedBits, idx);
}

static void htGrow(HashTable* ht) {
    size_t newCapacity = ht->capacity * 2;
    HashEntry* newEntries = (HashEntry*)malloc(sizeof(HashEntry) * newCapacity);
    uint8_t* newBits = (uint8_t*)calloc((newCapacity + 7) / 8, 1);
    for (size_t i = 0; i < ht->capacity; ++i) {
        if (bitGet(ht->usedBits, i)) {
            htInsertRaw(newEntries, newBits, newCapacity, ht->entries[i].ip, ht->entries[i].count);
        }
    }
    free(ht->entries);
    free(ht->usedBits);
    ht->entries = newEntries;
    ht->usedBits = newBits;
    ht->capacity = newCapacity;
}

// Increment (or create) the count for an IP address. Grows the
// table automatically once load factor would exceed 0.7.
static void htIncrement(HashTable* ht, uint32_t ip, unsigned int count) {
    if ((ht->size + 1) * 10 > ht->capacity * 7) {
        htGrow(ht);
    }
    size_t mask = ht->capacity - 1;
    size_t idx = hashIp(ip, mask);
    while (bitGet(ht->usedBits, idx)) {
        if (ht->entries[idx].ip == ip) {
            ht->entries[idx].count += count;
            return;
        }
        idx = (idx + 1) & mask;
    }
    ht->entries[idx].ip = ip;
    ht->entries[idx].count = count;
    bitSet(ht->usedBits, idx);
    ht->size++;
}

// Move all occupied slots to the front of ht->entries, in place,
// using ht->usedBits to know which slots are valid. After this
// call, ht->entries[0 .. ht->size) holds exactly the data,
// with no second array ever allocated.
static void htCompactInPlace(HashTable* ht) {
    size_t writeIdx = 0;
    for (size_t i = 0; i < ht->capacity; ++i) {
        if (bitGet(ht->usedBits, i)) {
            if (writeIdx != i) {
                ht->entries[writeIdx] = ht->entries[i];
            }
            writeIdx++;
        }
    }
    free(ht->usedBits);
    ht->usedBits = nullptr;

    // Shrink the allocation down to exactly what's needed.
    size_t shrinkCount = (writeIdx == 0) ? 1 : writeIdx;
    HashEntry* shrunk = (HashEntry*)realloc(ht->entries, sizeof(HashEntry) * shrinkCount);
    if (shrunk) {
        ht->entries = shrunk;
    }
}

// ------------------------------------------------------------
// IP / number parsing helpers (plain character arrays only)
// ------------------------------------------------------------

// Pack "a.b.c.d" into a 32-bit integer as (a<<24)|(b<<16)|(c<<8)|d.
// Numeric comparison of the packed value then matches the natural
// numeric ordering of the dotted-decimal IP address.
static inline uint32_t ipToUint(const char* s, int len) {
    uint32_t result = 0;
    uint32_t octet = 0;
    for (int i = 0; i < len; ++i) {
        char c = s[i];
        if (c == '.') {
            result = (result << 8) | (octet & 0xFFu);
            octet = 0;
        } else if (c >= '0' && c <= '9') {
            octet = octet * 10u + (uint32_t)(c - '0');
        }
    }
    result = (result << 8) | (octet & 0xFFu);
    return result;
}

// Manual unsigned-integer parser (avoids relying on any library
// string-to-number conversion beyond simple char arithmetic).
static inline unsigned int parseCount(const char* s) {
    unsigned int value = 0;
    while (*s == ' ' || *s == '\t') s++;
    while (*s >= '0' && *s <= '9') {
        value = value * 10u + (unsigned int)(*s - '0');
        s++;
    }
    return value;
}

// ------------------------------------------------------------
// Manual quicksort operating directly on HashEntry records.
// Sort order: descending count, then ascending IP to break ties.
// ------------------------------------------------------------
static inline bool comesBefore(const HashEntry& a, const HashEntry& b) {
    if (a.count != b.count) return a.count > b.count; // higher count first
    return a.ip < b.ip;                                 // tie: smaller IP first
}

static inline void swapEntries(HashEntry* arr, size_t i, size_t j) {
    HashEntry tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
}

static void insertionSort(HashEntry* arr, long left, long right) {
    for (long i = left + 1; i <= right; ++i) {
        HashEntry key = arr[i];
        long j = i - 1;
        while (j >= left && comesBefore(key, arr[j])) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

// Iterative quicksort (own explicit stack, no recursion) with a
// random pivot and "recurse into the smaller half" strategy, so
// stack usage stays O(log n) even on adversarial/sorted input.
// Falls back to insertion sort for small partitions.
static void quickSort(HashEntry* arr, long n) {
    if (n < 2) return;

    long stackCapacity = 128;
    long* stack = (long*)malloc(sizeof(long) * stackCapacity * 2);
    long top = 0;
    stack[top++] = 0;
    stack[top++] = n - 1;

    while (top > 0) {
        long right = stack[--top];
        long left = stack[--top];

        while (right - left > 16) {
            long pivotIdx = left + (rand() % (right - left + 1));
            swapEntries(arr, pivotIdx, right);
            HashEntry pivot = arr[right];

            long i = left - 1;
            for (long j = left; j < right; ++j) {
                if (comesBefore(arr[j], pivot)) {
                    i++;
                    swapEntries(arr, i, j);
                }
            }
            swapEntries(arr, i + 1, right);
            long p = i + 1;

            long leftSize = p - 1 - left;
            long rightSize = right - (p + 1);
            if (top + 4 > stackCapacity) {
                stackCapacity *= 2;
                stack = (long*)realloc(stack, sizeof(long) * stackCapacity * 2);
            }
            if (leftSize > rightSize) {
                stack[top++] = left;
                stack[top++] = p - 1;
                left = p + 1; // loop on the (larger) right half
            } else {
                stack[top++] = p + 1;
                stack[top++] = right;
                right = p - 1; // loop on the (larger) left half
            }
        }
        insertionSort(arr, left, right);
    }
    free(stack);
}

// ------------------------------------------------------------
// Core logic (shared by both entry points below)
// ------------------------------------------------------------
static void runAnalysis(char* inputFilePath, char* outputFilePath, int n) {
    if (n <= 0 || inputFilePath == nullptr || outputFilePath == nullptr) {
        return;
    }

    FILE* fp = fopen(inputFilePath, "r");
    if (!fp) {
        return;
    }

    srand(12345); // fixed seed for reproducible behavior/timing

    HashTable ht;
    htInit(&ht, 64); // small start; doubles as needed, keeps small-input memory low

    char line[256];
    while (fgets(line, sizeof(line), fp)) {
        char* comma = strchr(line, ',');
        if (!comma) continue;
        int ipLen = (int)(comma - line);
        uint32_t ip = ipToUint(line, ipLen);
        unsigned int cnt = parseCount(comma + 1);
        htIncrement(&ht, ip, cnt);
    }
    fclose(fp);

    // Compact used slots to the front IN PLACE (no second array),
    // then shrink the allocation to exactly ht.size entries.
    htCompactInPlace(&ht);
    size_t total = ht.size;

    quickSort(ht.entries, (long)total);

    FILE* out = fopen(outputFilePath, "w");
    if (!out) {
        htDestroy(&ht);
        return;
    }

    int importance = 0;
    unsigned int prevCount = 0;
    bool first = true;

    for (size_t i = 0; i < total; ++i) {
        if (first || ht.entries[i].count != prevCount) {
            importance++;
            prevCount = ht.entries[i].count;
            first = false;
        }
        if (importance > n) break;

        uint32_t ip = ht.entries[i].ip;
        fprintf(out, "%d, %u.%u.%u.%u, %u\n",
                importance,
                (ip >> 24) & 0xFFu, (ip >> 16) & 0xFFu,
                (ip >> 8) & 0xFFu, ip & 0xFFu,
                ht.entries[i].count);
    }

    fclose(out);
    htDestroy(&ht);
}

// ------------------------------------------------------------
// Public entry points
// ------------------------------------------------------------

// Free-function form, as originally described in the assignment PDF.
void getMostFrequentIPAddress(char* inputFilePath, char* outputFilePath, int n) {
    runAnalysis(inputFilePath, outputFilePath, n);
}

// Static class-method form, as actually invoked by the Gradescope
// grader (confirmed from the build log: IPAddressAnalyzer::getMostFrequentIPAddress).
void IPAddressAnalyzer::getMostFrequentIPAddress(char* inputFilePath, char* outputFilePath, int n) {
    runAnalysis(inputFilePath, outputFilePath, n);
}
