
#include "FixationPoints.h"

namespace {

constexpr const char* registrationNumber = "24022319141";
constexpr const char* inputFile = "../data/input.txt";
constexpr const char* outputFile = "../data/output.txt";
constexpr const char* separator = "***************";

}  // namespace

FixationPoints::FixationPoints() {
    for (unsigned int index = 0; index < kBucketCount; ++index) {
        buckets_[index] = nullptr;
    }
}

FixationPoints::~FixationPoints() {
    clear_table();
}

unsigned int FixationPoints::coordinate_key(int x, int y) {
    return static_cast<unsigned int>(x) * kCoordinateRange +
           static_cast<unsigned int>(y);
}

unsigned int FixationPoints::bucket_index(unsigned int key) {
    key ^= key >> 16U;
    key *= 0x7feb352dU;
    key ^= key >> 15U;
    return key % kBucketCount;
}

bool FixationPoints::insert_if_absent(unsigned int key) {
    const unsigned int index = bucket_index(key);
    HashNode* current = buckets_[index];

    // Walk the chain for this bucket to see if the key is already present.
    while (current != nullptr) {
        if (current->key == key) {
            return false;  // Duplicate coordinate: already inserted before.
        }
        current = current->next;
    }

    // Not found: allocate a new node and prepend it to the bucket's chain.
    HashNode* node = new HashNode;
    node->key = key;
    node->next = buckets_[index];
    buckets_[index] = node;

    return true;
}

void FixationPoints::clear_table() {
    for (unsigned int index = 0; index < kBucketCount; ++index) {
        HashNode* current = buckets_[index];
        while (current != nullptr) {
            HashNode* next = current->next;
            delete current;
            current = next;
        }
        buckets_[index] = nullptr;
    }
}

int FixationPoints::process_scanpath(FILE* input, FILE* output) {
    clear_table();
    int output_identifier = 1;

    int id = 0;
    int x = 0;
    int y = 0;

    while (fscanf(input, "%d %d %d", &id, &x, &y) == 3) {
        if (x == -1 && y == -1) {
            break;
        }

        const unsigned int key = coordinate_key(x, y);
        if (insert_if_absent(key)) {
            fprintf(output, "%d %d %d\n", output_identifier, x, y);
            ++output_identifier;
        }
    }

    fprintf(output, "%s\n", separator);

    return 0;
}

int FixationPoints::process() {
    FILE* input = fopen(inputFile, "r");
    if (input == nullptr) {
        return 1;
    }

    FILE* output = fopen(outputFile, "w");
    if (output == nullptr) {
        fclose(input);
        return 1;
    }

    fprintf(output, "%s\n", registrationNumber);

    int scanpath_count = 0;
    if (fscanf(input, "%d", &scanpath_count) != 1) {
        fclose(input);
        fclose(output);
        return 1;
    }

    for (int i = 0; i < scanpath_count; ++i) {
        process_scanpath(input, output);
    }

    fclose(input);
    fclose(output);

    return 0;
}
